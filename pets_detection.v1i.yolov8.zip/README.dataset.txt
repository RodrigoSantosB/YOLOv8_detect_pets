# pets_detection > 2023-11-19 4:36pm
https://universe.roboflow.com/animalsdetect/pets_detection

Provided by a Roboflow user
License: CC BY 4.0

